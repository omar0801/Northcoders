def lambda_handler(event, context):
    print('first project lambda function.....')